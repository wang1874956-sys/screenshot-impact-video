# 渲染与验证

## 已验证的实现要点

- 使用一个暂停的 GSAP 根时间线，并注册为 `window.__timelines.main`；根合成包含 data-composition-id、宽、高和时长。
- 初始隐藏状态写在 CSS 中，或立即 gsap.set；仅用暂停时间线在 0 秒 set 隐藏可能让首帧提前显示。
- 未来时刻的 fromTo 动画使用 `immediateRender:false`，避免后半段起始值污染前半段。需要有意预置的情况应明确安排初始状态。
- 区分输出尺寸、CSS 设计尺寸、原图尺寸。裁切背景的位置与 background-size 必须使用同一坐标系，最后统一缩放。
- 谨慎使用跨容器的 preserve-3d。负深度图层可能和桌面平面相交；必要时将父容器展平，只在元素自身保留透视变换。
- 裁切图层仍带着原截图背景，旋转和重叠时会遮住邻近内容。检查关键帧，调整间距、层级或裁切方案；不要把这种遮挡当作自动抠图。
- 音频元素需要稳定唯一的 id，以及 data-start 和 data-duration，否则渲染器可能无法发现轨道。
- 轨迹、变速和音效使用确定性的时间线与种子；不要用实时随机数控制逐帧动作。

## 本地渲染

按当前 HyperFrames 技能与 CLI 的真实安装情况操作。既有样例使用过以下命令形式：

```powershell
python ./build.py
npx hyperframes check --at '0.5,2,6,10,15,18' --snapshots
npx hyperframes render --output './demo.mp4' --fps 30 --quality high --workers 3
```

命令中的采样时间不能超过实际片长。检查可能只保存部分指定采样点；需要额外帧时单独捕获。优先复用已有、可运行的本地 CLI，避免为每次样片重新下载依赖。

Windows 上曾通过 HYPERFRAMES_BROWSER_PATH、HYPERFRAMES_FFMPEG_PATH、HYPERFRAMES_FFPROBE_PATH 指定本机运行时。路径属于具体机器，先发现实际位置，不复制旧项目的 npm 缓存路径作为通用配置。浏览器预检若受到沙箱限制，使用正常的工具审批机制导出已获用户授权的本地视频。

导出后用 ffprobe 或等效工具确认 H.264 视频、所需音轨、时长、尺寸及帧率；抽看实际 MP4 中的关键帧。检查通过不等于画面好看，最终仍须视觉检查。
