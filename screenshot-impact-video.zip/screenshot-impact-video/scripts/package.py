"""Build a shareable repository ZIP from an explicit public file allowlist."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
archive = root.parent / 'screenshot-impact-video-public-draft.zip'
files = []
for name in ('README.md', '.gitignore', 'LICENSE'):
    path = root / name
    if path.is_file():
        files.append(path)
for name in ('skills', 'scripts', 'tests', 'examples'):
    for path in (root / name).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            files.append(path)
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for path in sorted(files):
        output.write(path, Path('screenshot-impact-video') / path.relative_to(root))
print(f'Packaged {len(files)} public files: {archive}')
